const availableUsers = [
    {
        id: 1,
        name: "John Smith",
        usuario: "jhon123",
        email: "john.smith@example.com",
	    password: "abc", 
        role: "admin"
    },
    {
        id: 2,
        name: "Jane Doe",
        usuario: "jane123",
        email: "jane.doe@example.com",
	    password: "123",
        role: "user"
    },
    {
        id: 3,
        name: "Bob Johnson",
        usuario: "bob123",
        email: "bob.johnson@example.com",
	    password: "xyz",
        role: "user"
    },
    {
        id: 4,
        name: "Carlos",
        usuario: "carlos123",
        email: "a",
	    password: "a", 
        role: "admin"
    }
]